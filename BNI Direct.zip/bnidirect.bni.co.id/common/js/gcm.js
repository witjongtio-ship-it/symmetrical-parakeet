function setFocusRadioButton(radioObj, val) {
    if (!radioObj)
        return;

    var radioLength = radioObj.length;

    if (radioLength == undefined) {
        radioObj.checked = radioObj.value == val.toString();

        return;
    }

    for (var i = 0; i < radioLength; i++)
        radioObj[i].checked = radioObj[i].value == val.toString();
}

function validateNotification(regex, notifyValue) {
    var reg = new RegExp(regex);
    return reg.test(notifyValue);
}

function validateEmail(email) {
    var a = false;
    var res = false;

    if (typeof (RegExp) == 'function') {
        var b = new RegExp('abc');
        if (b.test('abc') == true)
            a = true;
    }

    if (a == true) {
        reg = new RegExp('^([a-zA-Z0-9\\-\\.\\_]+)' + '(\\@)([a-zA-Z0-9\\-\\.]+)' + '(\\.)([a-zA-Z]{2,4})$');
        res = (reg.test(email));
    } else {
        res = (email.search('@') >= 1 &&
            email.lastIndexOf('.') > email.search('@') &&
            email.lastIndexOf('.') >= email.length - 5)
    }

    return (res);
}

function validateMultipleEmail(objectFormBeneficiaryEmail, objectFormNotifyRegex, errorMessageMandatory, errorMessageInvalidEmail) {
    if (objectFormBeneficiaryEmail.value == "") {
        alert(errorMessageMandatory);
        objectFormBeneficiaryEmail.focus();

        return false;
    } else {
        var tempArr = objectFormBeneficiaryEmail.value.split(";");
        var tempArrSize = tempArr.length;

        for (i = 0; i < tempArrSize; i++) {
            var tempArr2 = tempArr[i].split(",");
            var tempArr2Size = tempArr2.length;

            if (tempArr2Size > 1) {
                for (j = 0; j < tempArr2Size; j++) {
                    if (!validateNotification(objectFormNotifyRegex.value, tempArr2[j])) {
                        alert(errorMessageInvalidEmail);
                        form.beneficiaryEmail.focus();

                        return false;
                    }
                }
            } else if (!validateNotification(objectFormNotifyRegex.value, tempArr[i])) {
                alert(errorMessageInvalidEmail);
                objectFormBeneficiaryEmail.focus();

                return false;
            }
        }
    }

    return true;
}

function checkOnlineBalance(acctNo) {
    if (acctNo == '' || acctNo == null) {
        alert(accountNoMessage);
        return;
    }

    sUrl = "/corp/front/balanceinquiry.do?action=detailRequest&fromurl=domtransfer&accNumber=" + acctNo;
    sProps = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=600,height=400";

    wAcctList = window.open(sUrl, "aaaaa", sProps);
    wAcctList.window.focus();
}

function onSaveas() {
    var browser = navigator.appName
    var browserName = navigator.appName
    if (browser == "Microsoft Internet Explorer") {
        if (document.all) {
            document.execCommand('SaveAs', false, '*.htm');
        } else if (document.getElementById) {
            document.execCommand('SaveAs', false, '*.htm');
        } else if (document.layers) {
            document.execCommand('SaveAs', false, '*.htm');
        } else {
            alert(alertSaveAsError);
        }
    } else {
        alert(alertSaveAsError);
    }
}

function checkExpired(form) {
    if (form.expiredDay.value == "" || form.expiredMonth.value == "" || form.expiredYear.value == "") {

        return false;
    } else
        return true;


}

function printpage() {
    window.print();
}

function closePrintPage() {
    window.close();
}

function OnClickRefreshOnlineBalance(form) {
    form.action = '/corp/front/balanceinquiry.do?action=detailRequest&accNumber=' + form.accountNumber.value;
    form.submit();
}

function changeValue(form) {
    var divDay = document.getElementById("dayDiv");
    var divDate = document.getElementById("dateDiv");
    var divDaily = document.getElementById("dailyDiv");
    if (form.every != undefined) {
    if (form.every.value == 'W') {
        divDay.style.display = 'block';
        divDate.style.display = 'none';
        divDaily.style.display = 'none';
    } else if (form.every.value == 'M') {
        divDay.style.display = 'none';
        divDate.style.display = 'block';
        divDaily.style.display = 'none';
    } else {
        divDay.style.display = 'none';
        divDate.style.display = 'none';
        divDaily.style.display = 'block';
    }
}
}

function onBodyLoad() {
    var oForm = eval("document.forms[0]");

    if (oForm.every != undefined) {
        if (oForm.every.value == 'M') {
            document.getElementById("dayDiv").style.display = "none";
            document.getElementById("dateDiv").style.display = "block";
            document.getElementById("dailyDiv").style.display = "none";
        } else if (oForm.every.value == 'D') {
            document.getElementById("dayDiv").style.display = "none";
            document.getElementById("dateDiv").style.display = "none";
            document.getElementById("dailyDiv").style.display = "block";
        }
    }
}

function validateStandingInstruction(form) {
    if (form.standingInstruction.length != undefined) {
        for (var i = 0; i < form.standingInstruction.length; i++) {
            if (form.standingInstruction[i].checked && form.standingInstruction[i].value == '3') {
                if (form.scheduleDay1.value == '') {
                    alert(errorFutureDate);

                    return false;
                }
            } else if (form.standingInstruction[i].checked && form.standingInstruction[i].value == '4') {
                if (form.everyDay1.value == '') {
                    alert(errorExpiredDate);

                    return false;
                }

                form.everyDisplay.value = form.every[form.every.selectedIndex].text;
                form.dayDisplay.value = form.day[form.day.selectedIndex].text;
                form.dateDisplay.value = form.date[form.date.selectedIndex].text;
                form.dailyDisplay.value = form.daily[form.daily.selectedIndex].text;
            }
        }
    } else {
        if (form.standingInstruction.checked && form.standingInstruction.value == '3') {
            if (form.scheduleDay1.value == '') {
                alert(errorFutureDate);

                return false;
            }
        } else if (form.standingInstruction.checked && form.standingInstruction.value == '4') {
            if (form.everyDay1.value == '') {
                alert(errorExpiredDate);

                return false;
            }

            form.everyDisplay.value = form.every[form.every.selectedIndex].text;
            form.dayDisplay.value = form.day[form.day.selectedIndex].text;
            form.dateDisplay.value = form.date[form.date.selectedIndex].text;
            form.dailyDisplay.value = form.daily[form.daily.selectedIndex].text;
        }
    }

    return true;
}

function validateTotalAmount(form) {
    if (form.totalAmount.value == '') {
        alert(errorTotalAmount);

        form.totalAmount.focus();

        return false;
    }

    reTest = new RegExp("^[0-9]+$|^[0-9]+[.]?[0-9]+$");

    if (!reTest.test(form.totalAmount.value)) {
        alert(errorTotalAmountNum);

        form.totalAmount.focus();

        return false;
    }

    return true;
}

function validateTotalAmountForWorkFlow(totalAmount) {
    if (totalAmount == '') {
        alert(errorTotalAmount);

        return false;
    }

    reTest = new RegExp("^[0-9]+$|^[0-9]+[.]?[0-9]+$");

    if (!reTest.test(totalAmount)) {
        alert(errorTotalAmountNum);

        return false;
    }

    return true;
}

function validateTotalAmountForWorkFlowForLiquidityManagement(totalAmount) {
    if (totalAmount == '') {
        alert(errorTotalAmount);

        return false;
    }

    reTest = new RegExp("^[0-9]+$|^[0-9]+[.]?[0-9]+$");

    if (!reTest.test(totalAmount) && totalAmount != '-1') {
        alert(errorTotalAmountNum);

        return false;
    }

    return true;
}

function validateCode(testValue) {
    reTest = new RegExp("^[0-9a-zA-Z_-]+$");

    return reTest.test(testValue);
}

function validateInteger(number) {
    reg = new RegExp("^[0-9]+$");
    return reg.test(number);
}

function validateResponseNo(responseNo, msg) {
    if (responseNo == '') {
        alert(msg);
        return false;
    } else
        return true;
}

function onlineBalanceClick(accountNumber) {
    if (accountNumber == '') {
        alert(alertAccountNo);
    } else {
        window.open("/corp/common/online_balance.do?action=cekOnlineBalance&accountNumber=" + accountNumber, 'popupWindow',
            'toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=600,height=500,top=100,left=100');
    }
}

function onWorkflowInfoClick(form, totalAmount, currencyCode, currencyFromAccount, fromAccountNo) {

    if (fromAccountNo == "") {
        alert(errorFrAccountNo);
        return;
    }

    if (!validateTotalAmountForWorkFlow(totalAmount))
        return;

    window.open("/corp/common/workflowaction.do?action=doViewWorkflowInfo&totalAmount=" + totalAmount + "&currencyCode=" + currencyCode + "&frAccountCurrency=" + currencyFromAccount + "&fromAccountNo=" + fromAccountNo, 'popupWindow',
        'toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=600,height=500,top=100,left=100');
}

function onWorkflowInfoClickForLiquidityManagement(form, totalAmount, currencyCode, currencyFromAccount, fromAccountNo) {

    if (fromAccountNo == "") {
        alert(errorFrAccountNo);
        return;
    }

    if (!validateTotalAmountForWorkFlowForLiquidityManagement(totalAmount))
        return;

    window.open("/corp/common/workflowaction.do?action=doViewWorkflowInfo&totalAmount=" + totalAmount + "&currencyCode=" + currencyCode + "&frAccountCurrency=" + currencyFromAccount + "&fromAccountNo=" + fromAccountNo, 'popupWindow',
        'toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=600,height=500,top=100,left=100');
}

function onlineBalanceCustomClick(accountNumber) {
    if (accountNumber == '' || accountNumber == " ") {
        alert(alertAccountNo);
    } else {
        window.open("/corp/common/online_balance.do?action=cekOnlineBalance&checkFlag=Y&accountNumber=" + accountNumber, 'popupWindow',
            'toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=600,height=500,top=100,left=100');
    }
}

function terbilang() {

    var form = document.forms[0];

    bilangan = String(form.totalAmount.value);
    var angka = new Array('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
    var kata = new Array('', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Delapan', 'Sembilan');
    var tingkat = new Array('', 'Ribu', 'Juta', 'Milyar', 'Triliun');

    var panjang_bilangan = bilangan.length;

    /* mengambil angka-angka yang ada dalam bilangan, dimasukkan ke dalam array */
    for (i = 1; i <= panjang_bilangan; i++) {
        angka[i] = bilangan.substr(-(i), 1);
    }

    i = 1;
    j = 0;
    kaLimat = "";


    /* mulai proses iterasi terhadap array angka */
    while (i <= panjang_bilangan) {

        subkaLimat = "";
        kata1 = "";
        kata2 = "";
        kata3 = "";

        /* untuk Ratusan */
        if (angka[i + 2] != "0") {
            if (angka[i + 2] == "1") {
                kata1 = "Seratus";
            } else {
                kata1 = kata[angka[i + 2]] + " Ratus";
            }
        }

        /* untuk Puluhan atau Belasan */
        if (angka[i + 1] != "0") {
            if (angka[i + 1] == "1") {
                if (angka[i] == "0") {
                    kata2 = "Sepuluh";
                } else if (angka[i] == "1") {
                    kata2 = "Sebelas";
                } else {
                    kata2 = kata[angka[i]] + " Belas";
                }
            } else {
                kata2 = kata[angka[i + 1]] + " Puluh";
            }
        }

        /* untuk Satuan */
        if (angka[i] != "0") {
            if (angka[i + 1] != "1") {
                kata3 = kata[angka[i]];
            }
        }

        /* pengujian angka apakah tidak nol semua, lalu ditambahkan tingkat */
        if ((angka[i] != "0") || (angka[i + 1] != "0") || (angka[i + 2] != "0")) {
            subkaLimat = kata1 + " " + kata2 + " " + kata3 + " " + tingkat[j] + " ";
        }

        /* gabungkan variabe sub kaLimat (untuk Satu blok 3 angka) ke variabel kaLimat */
        kaLimat = subkaLimat + kaLimat;
        i = i + 3;
        j = j + 1;

    }

    /* mengganti Satu Ribu jadi Seribu jika diperlukan */
    if ((angka[5] == "0") && (angka[6] == "0")) {
        kaLimat = kaLimat.replace("Satu Ribu", "Seribu");
    }

    form.amountInWord.value = kaLimat + "Rupiah";
}

function changeIframeSrc(url) {
    parent.frames[2].location = url;
}

//ALVIN - DOWNLOADUSERGUIDE - START
function doDownloadUG(type) {
    var form = eval("document.forms[0]");
    var downloadUGRequest = "/corp/common/login.do?action=doDownloadUG";

    if (type == 'HTL') {
        form.action = downloadUGRequest + "&type=HTL";
    } else if (type == 'CP') {
        form.action = downloadUGRequest + "&type=CP";
    } else if (type == 'TS') {
        form.action = downloadUGRequest + "&type=TS";
    } else if (type == 'FSA') {
        form.action = downloadUGRequest + "&type=FSA";
    } else if (type == 'FT') {
        form.action = downloadUGRequest + "&type=FT";
    } else if (type == 'QG') {
        form.action = downloadUGRequest + "&type=QG";
    }
    form.submit();
}

//ALVIN - DOWNLOADUSERGUIDE - END

//Feliz - Help and Support - START
function onClickHelpAndSupport(id) {
    window.open("/corp/front/helpandsupport.do?action=doSearchRequest&helpAndSuppportId=" + id, 'popupWindow',
        'toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=900,height=400,top=100,left=100');
}

//Feliz - Help and Support - END

// Start ---- Back Detect Browser
var detectedFrame = new BackDetectObj();
window.addEventListener('load', function () {
    var alertMessage = 'You have been logged out from the system';
    detectedFrame.element = document.getElementsByTagName('body')[0];
    detectedFrame.callback = function () {
        alert(alertMessage);
        top.location.href = '/corp/common/login.do?action=logout';
    };
    detectedFrame.detectBack();
});

function BackDetectObj() {
    this.values = {
        frameLoaded: 0,
        frameTry: 0,
        frameTime: 0,
        frameDetect: null,
        frameSrc: null,
        frameCallBack: null,
        frameThis: null,
        frameNavigator: window.navigator.userAgent,
        frameDelay: 0,
        frameDataSrc: '',
    };
    this.element = null;
    this.callback = null;
    this.delay = 0;
}

BackDetectObj.prototype.detectBack = function () {
    var self = this,
        backDetectValues = this.values;
    backDetectValues.frameThis = self.element;
    backDetectValues.frameCallBack = self.callback;
    if (self.delay !== null) {
        backDetectValues.frameDelay = self.delay;
    }


    setTimeout(function loadFrame() {
        var contentIframe = document.createElement('iframe');
        contentIframe.style.display = 'none';
        contentIframe.src = 'about:blank?loading';
        contentIframe.onload = function () {
            BackDetectObj.prototype.frameInit.call(this)
        };
        contentIframe.id = 'backDetectFrame';
        backDetectValues.frameThis.appendChild(contentIframe);
    }, backDetectValues.frameDelay);
};

BackDetectObj.prototype.frameInit = function () {
    var backDetectValues = detectedFrame.values;
    backDetectValues.frameDetect = document.getElementById('backDetectFrame');
    if (backDetectValues.frameLoaded > 1) {
        if (backDetectValues.frameLoaded === 2) {
            backDetectValues.frameCallBack();

        }
    }
    backDetectValues.frameLoaded += 1;
    if (backDetectValues.frameLoaded === 1) {
        backDetectValues.frameTime = setTimeout(function beginFrameSetup() {
            detectedFrame.setupFrames.call(this);
        }, 500);
    }
};

BackDetectObj.prototype.setupFrames = function () {
    var self = detectedFrame,
        backDetectValues = self.values;
    clearTimeout(backDetectValues.frameTime);
    backDetectValues.frameSrc = backDetectValues.frameDetect.src;
    if (backDetectValues.frameLoaded === 1 && backDetectValues.frameSrc.indexOf('historyLoaded') === -1) {
        if (backDetectValues.frameNavigator.indexOf('MSIE ') > -1 || backDetectValues.frameNavigator.indexOf('Trident') > -1) {
            backDetectValues.frameDetect.src = backDetectValues.frameDataSrc + '?historyLoaded';
        } else {
            backDetectValues.frameDetect.src = 'about:blank?historyLoaded';
        }
    }
};
// End ---- Back Detect Browser


// Start ---- on Load listener (for scroll top purpose)
function onLoadListener() {
    window.top.scrollTo(0, 0);
}

window.addEventListener('load', onLoadListener);
// End ---- on Load listener (for scroll top purpose)


// Start ---- Left Menu Helper
function changeLeftMenuState() {
    var reportMenuCode = 'MNU_GCME_180000',
        downloadReportMenuCode = 'MNU_GCME_180800';
    new LeftMenuUtil(reportMenuCode, downloadReportMenuCode).openParentHeadCollapsible();
}

function changeLeftMenuStateBeneName() {
    var reportMenuCode = 'MNU_GCME_130000',
        downloadReportMenuCode = 'MNU_GCME_100300';
    new LeftMenuUtil(reportMenuCode, downloadReportMenuCode).openParentHeadCollapsible();
}

function changeLeftMenuStateAdminBeneName() {
    var reportMenuCode = 'MNU_GCME_020000',
        downloadReportMenuCode = 'MNU_GCME_100300';
    new LeftMenuUtil(reportMenuCode, downloadReportMenuCode).openParentHeadCollapsible();
}

function changeLeftMenuStateBillPayment() {
    var reportMenuCode = 'MNU_GCME_600000',
        downloadReportMenuCode = 'MNU_GCME_600400';
    new LeftMenuUtil(reportMenuCode, downloadReportMenuCode).openParentHeadCollapsible();
}

function changeLeftMenuFromFavorite(parentCode, childCode) {
    new LeftMenuUtil(parentCode, childCode).openParentHeadCollapsible();
}

/**
 * left menu helper class
 * @param parentMenuCode
 * @param childMenuCode
 * @constructor
 */
function LeftMenuUtil(parentMenuCode, childMenuCode) {
    this.sideBarEl = window.top.document.getElementById('sidebar').contentWindow.document;
    this.parentMenuCode = parentMenuCode;
    this.childMenuCode = childMenuCode;
}

/**
 * open collapsible parent accordion menu
 */
LeftMenuUtil.prototype.openParentHeadCollapsible = function () {
    try {
        var parentCode = 'parent-' + this.parentMenuCode,
            collapsedBodyEl = this.sideBarEl.getElementsByClassName(parentCode)[0],
            collapsedHeaderEl = this.sideBarEl.getElementById(parentCode);
        collapsedHeaderEl.setAttribute('aria-expanded', true);
        collapsedHeaderEl.classList.remove('collapsed');
        collapsedBodyEl.classList.add('collapse', 'show');
    } catch (e) {
        throw new Error('Parent menu not found');
    } finally {
        this.setMenuActive(this.childMenuCode);
    }
};

/**
 * hide all open collapsible
 */
LeftMenuUtil.prototype.hideCurrentCollapsible = function () {
    try {
        var collapsedBodyMenuEl = this.sideBarEl.getElementsByClassName('collapse show');
        for (i=0; i <collapsedBodyMenuEl.length; i++) { 
        	var collapsedEl = collapsedBodyMenuEl[i].getAttribute('data-parentcode');
        	if ('parent-' + this.parentMenuCode!=collapsedEl) {
        		collapsedHeadMenuEl = this.sideBarEl.getElementById(collapsedEl);
        collapsedHeadMenuEl.setAttribute('aria-expanded', false);
        collapsedHeadMenuEl.classList.add('collapsed');
                collapsedBodyMenuEl[i].classList.remove('show');
        	}
        }
    } catch (e) {
        throw new Error(e);
    }
};

/**
 * set menu active
 */
LeftMenuUtil.prototype.setMenuActive = function () {
    try {
        var menuActive = this.sideBarEl.getElementsByClassName('menu-item active');
        for (var i = 0; i < menuActive.length; i++) {
            menuActive[i].classList.remove('active');
        }
        var childMenuEl = this.sideBarEl.getElementById('child-' + this.childMenuCode);
        childMenuEl.className += ' active';
        this.hideCurrentCollapsible();
    } catch (e) {
    	this.closeParentHeadCollapsible();
        alert(invalidMenuChild);
        throw new Error(invalidMenuChild + ' error occurred');
    }
};

/**
 * close parent collapsible menu based on parent menu code
 */
LeftMenuUtil.prototype.closeParentHeadCollapsible = function () {
    var parentCode = 'parent-' + this.parentMenuCode,
        collapsedBodyEl = this.sideBarEl.getElementsByClassName(parentCode)[0],
        collapsedHeaderEl = this.sideBarEl.getElementById(parentCode);
    collapsedHeaderEl.setAttribute('aria-expanded', false);
    collapsedHeaderEl.classList.add('collapsed');
    collapsedBodyEl.classList.remove('show');
};
// End ---- Left Menu Helper


function checkRadioBtn(elmt,val){
	if(elmt === undefined)
		return false;
	if(elmt.length !== undefined){
		var size = elmt.length;
		for(i=0;i<size ;i++){
			if(elmt[i].checked && elmt[i].value == val)
				return true;
		}
		return false;
	}
	if(elmt.value == val)
		return true;
	return false;
}

function goToMobileTokenMenuRightTab() {
    var form = document.forms[0];
    form.action = "/corp/front/mobiletoken.do?action=doSearchRequest&tabActive=MobileTokenInfo";
    form.submit();
}

function onlyNumberWithDecimal(evt) {
    var e = evt || window.event; // IE lama pakai window.event, bukan parameter
    var charCode = e.which || e.keyCode; // e.which untuk browser modern, e.keyCode untuk IE
    var value = e.target ? e.target.value : e.srcElement.value; // e.target modern, e.srcElement IE

    if (charCode === 0) {
        return true;
    }

    var charStr = String.fromCharCode(charCode);

    if (charStr >= "0" && charStr <= "9") {
        return true;
    }

    if (charStr === "." && value.indexOf(".") === -1) {
        return true;
    }

    if (e.preventDefault) {
        e.preventDefault();
    }
    return false;
}

function blockPaste(evt) {
    var e = evt || window.event;
    var target = e.target || e.srcElement;

    console.log("Block Paste: " + target.name);

    if (e.preventDefault) {
        e.preventDefault();
    }
    return false;
}

function attachPasteBlock(elementName) {
    var elements = document.getElementsByName(elementName);
    if (!elements || elements.length === 0) {
        return;
    }
    var el = elements[0];

    if (el.addEventListener) {
        el.addEventListener("paste", blockPaste, false);

    } else if (el.attachEvent) {
        el.attachEvent("onpaste", blockPaste);
    }
}