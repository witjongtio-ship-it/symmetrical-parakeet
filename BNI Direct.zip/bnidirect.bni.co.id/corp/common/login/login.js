var toggle = false;

function onLoginClick() {
    var form = eval("document.forms[0]");
    form.password.value = "";

    if (form.corpId.value == "") {
        alert(corpIdIsMandatory);

        form.corpId.focus();

        return;
    }
    else if (form.userName.value == "") {
    	alert(userNameIsMandatory);

        form.userName.focus();

        return;
    } else if (form.passwordEncryption.value == "") {
    	alert(passwordIsMandatory);

        form.passwordEncryption.focus();

        return;
    }
    
    //if(form.language.value == "undefined" || form.language.value == ""){
    form.language.value = languageLocale;
    //}
     
    form.action = loginRequest;
    //WILLY FIX SECURITY - Cleartext Password Sent With Hashed Password
    //form.password.value = hex_md5(form.passwordEncryption.value);
    form.password.value = hex_md5(form.passwordEncryption.value);
    //form.password.value = hex_sha1(form.passwordEncryption.value);
    form.passwordEncryption.value = "";
    form.submit();
}

function placeholder(){
	$("#corpId_placeholder").attr("placeholder" , cordIdPlaceholder);
	$("#userName_placeholder").attr("placeholder" , userNamePlaceholder);
	$("#password_placeholder").attr("placeholder" , passwordPlaceholder);
}

function onlanguageclickFR() {
	var form = eval("document.forms[0]");
	form.language.value = "fr_FR";
	
	form.action = changelang+"&lang=IDR";
	form.submit();
}

function onlanguageclickUS() {
	var form = eval("document.forms[0]");
	form.language.value = "en_US";
	
	form.action = changelang+"&lang=US";;
	form.submit();
}
function onlanguageclickCN() {
	var form = eval("document.forms[0]");
	form.language.value = "zh_CN";
	
	form.action = changelang+"&lang=CN";;
	form.submit();
}

function onClearClick() {
	var form = eval("document.forms[0]");
    form.corpId.value = "";
    form.userName.value = "";
    form.passwordEncryption.value = "";
   
}

function nof5(){
	if(window.frames&&window.frames[0]){
    	window.frames[0].focus();
    	for (var i_tem = 0; i_tem < window.frames.length; i_tem++)
    	if(document.all&&document.body.filters)
    	window.frames[i_tem].document.onkeydown=new Function("vare=window.frames["+i_tem+"].event; if(e.keyCode==116){e.keyCode=0;returnfalse;};");
    	else if(document.getElementById)
    	window.frames[i_tem].onkeypress=new Function("e","if(e.keyCode==116){e.preventDefault();e.stopPropagation();}")
	}
}

function onCheckError(){
    if(errorMessage != null && errorMessage != "" )
    alert(errorMessage);
}
function doLogin(event)
{
    
if ((event.keyCode==13) || (event.which==13))
{
	onLoginClick();

}

}

function doTermOfCondition() {
	sProps = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=800,height=600";
    
	window.open(termOfConditionRequest, "termOfCondition", sProps);
}

function doTermOfUsingRupiah() {
	sProps = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width=800,height=600";
    
	window.open(termOfUsingRupiahRequest, "termOfUsingRupiah", sProps);
}
// ANTON - CRFORGOTPASS - START
function doForgotPassword(){
	window.location.href = forgotPassword;
}
 // ANTON - CRFORGOTPASS - END

//AGUS - Lock Unlock User
function onStillLoginClick() {
    var form = eval("document.forms[0]");

    if (!form.password.value) {
    	alert(passwordIsMandatory);

        form.passwordEncryption.focus();

        return;
    }
    if(form.language.value == "undefined" || form.language.value == ""){
    	form.language.value = "fr_FR";
    }
     
    form.action = loginRequest+"&isFromPopup=Y";
    form.submit();
}

function onClickModalConfirm() {
    var form = eval("document.forms[0]");
    var checkbox1 = document.getElementById("checkBox1")
    var checkbox2 = document.getElementById("checkBox2")
    
	if (checkbox1.checked) {
	    form.checkBoxTerm.value = "true";
	} else {
	    form.checkBoxTerm.value = "false";
	}

	if (checkbox2.checked) {
	    form.checkBoxHider.value = "true";
	} else {
	    form.checkBoxHider.value = "false";
	}
	
	addOrUpdateCookie("hiderLoginPopUpFlag", form.checkBoxHider.value, 365);
}

function setCookie(cookieName, cookieValue, expirationDays) {
    var date = new Date();
    date.setTime(date.getTime() + (expirationDays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + date.toUTCString();
    document.cookie = cookieName + "=" + cookieValue + ";" + expires + ";path=/";
}

function addOrUpdateCookie(cookieName, cookieValue, expirationDays) {
    var existingCookie = getCookie(cookieName);
    if (existingCookie !== null) {
        existingCookie.value = cookieValue;
        setCookie(cookieName, existingCookie.value, expirationDays);
    } else {
        setCookie(cookieName, cookieValue, expirationDays);
    }
}

function getCookie(cookieName) {
    var name = cookieName + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var cookieParts = decodedCookie.split(';');
    for (var i = 0; i < cookieParts.length; i++) {
        var cookie = cookieParts[i];
        while (cookie.charAt(0) === ' ') {
            cookie = cookie.substring(1);
        }
        if (cookie.indexOf(name) === 0) {
            var value = cookie.substring(name.length, cookie.length);
            return { name: cookieName, value: value };
        }
    }
    return null;
}

function doPeekToggle() {
    var form = eval("document.forms[0]");

    if (toggle == false) {
        form.passwordEncryption.setAttribute("type", "text");
        form.visibilityIcon.setAttribute("src", "/images/nextgenimage/icons/visibility_off.png");
        toggle = true;
    } else {
        form.passwordEncryption.setAttribute("type", "password");
        form.visibilityIcon.setAttribute("src", "/images/nextgenimage/icons/visibility.png");
        toggle = false;
    }

}

